#ifndef BATTLEFIELD_H_INCLUDED
#define BATTLEFIELD_H_INCLUDED
#include <iostream>
#include <string>
#include <vector>
#include <tuple>
#include <cstdlib>
#include <ctime>
#include <streambuf>
#include "LinkedList.h"

using namespace std;

// ---------- Class Battlefield ----------
class Battlefield
{
protected:
    vector<tuple<string, string, string>> randomRobots;     // Initialise list to store robots with random as coordinates
    set<pair<int, int>> occupiedPositions;   // Initialise list to store coordinates that are occupied by robots with fixed initial position

public:
    Battlefield(){}
    const int initialLength = 6;    // for formatting grid use

    int turn, robotNum;
    int rows, cols;
    string** grid;     // Create a multidimensional array and implement after getting cols & rows
    int robotPosX, robotPosY;
    int randX, randY;

    robotActionList<string, int> robotActions;  // Include an instance of robotActionList
    DeadRobotQueue<string, int> deadrobot; // Include an instance of DeadRobotQueue that stores dead robots waiting to revive
    DeadRobotQueue<string, int> endGameRobot;  // Include an instance of DeadRobotQueue that stores fully dead robots (gg)

    int ReadFile();
    void PlaceRobot(string &robotID, int x, int y);
    void DisplayBattlefield(ostream &out);
    void ExecuteTurn(ostream &out);
    void StartSimulation(ostream &out);
    void updateRobotPosition(string& robotID, int newX, int newY, int check);
    void setposition(int PosX, int PosY){
        robotPosX = PosX;
        robotPosY =PosY;
    }
    void randomRobotGenerator(bool checkPassed);
    int getRandX(bool checkPassed);
    int getRandY(bool checkPassed);

    friend ostream& operator << (ostream &out, Battlefield &obj);       // friend the operator overload function so that it can iterate the members of this class

    ~Battlefield()
    {
        // Deallocate grid after use to free memory
        for (int i = 0; i < rows; i++)
        {
            delete[] grid[i];
        }
        delete[] grid;

    }
};

// Function to get random x numbers
int Battlefield::getRandX(bool checkPassed){
    randomRobotGenerator(checkPassed);
    return randX;
}

// Function to get random y numbers
int Battlefield::getRandY(bool checkPassed){
    randomRobotGenerator(checkPassed);
    return randY;
}

// Function to generate random numbers
void Battlefield::randomRobotGenerator(bool checkPassed){
    vector<pair<int,int>> existingRobotPositions = robotActions.getAllRobotPositions();
    for(const auto &pos : existingRobotPositions){
        occupiedPositions.insert(pos);
    }

    //srand(1211108242); // Set seed as student id of leader for random
    //cout << time(NULL) << endl;
    srand(time(NULL)); // Set seed for random
    if(checkPassed==true)
    {
        do{
            randX = rand() % cols;       // Generate random x,y positions in range of cols and rows of battlefield
            randY = rand() % rows;
        }while(occupiedPositions.find(make_pair(randX, randY)) != occupiedPositions.end());
    }
    else
    {
        for(const auto& robot : randomRobots)
        {
            string robotID = get<0>(robot);

            do{
                randX = rand() % cols;       // Generate random x,y positions in range of cols and rows of battlefield
                randY = rand() % rows;
            }while(occupiedPositions.find(make_pair(randX, randY)) != occupiedPositions.end());

            PlaceRobot(robotID, randX, randY);  // Place the robots based on random coordinate generated
            robotActions.push_back1(robotID,randX,randY);     // Add the robots to back of LinkedList
            occupiedPositions.insert(make_pair(randX, randY)); // Mark the position as occupied
        }
    }

    occupiedPositions.clear();
}

// Update position at the grid
void Battlefield::updateRobotPosition(string& robotID, int newX, int newY, int check)
{
    // Check validity of newX and newY here
    if (newX >= 0 && newX < cols && newY >= 0 && newY < rows)
    {
        //check = 1 for move , step ; check =0 for fire(ori position no change)
        if(check == 1)
        {
            // Update grid with new position
            grid[robotPosY][robotPosX] = "NULL"; // Clear old position
            grid[newY][newX] = robotID; // Update new position
            PlaceRobot(robotID, newX, newY);
        }
        else if(check == 0)
        {
            grid[newY][newX] = "NULL"; // Clear old position
        }
    }
    else
    {
        cerr << "Invalid position (" << newX << "," << newY << "). Position out of bounds." << endl;
    }
}

// Class to ostream simultaneosuly to terminal and output file
class dual_streambuf : public streambuf
{
public:
    dual_streambuf(streambuf* buf1, streambuf* buf2) : buf1(buf1), buf2(buf2) {}
protected:
    virtual int overflow(int c) override
    {
        if (c == EOF)
        {
            return !EOF;
        } else
        {
            int const r1 = buf1->sputc(c);
            int const r2 = buf2->sputc(c);
            return (r1 == EOF || r2 == EOF) ? EOF : c;
        }
    }

    virtual int sync() override
    {
        int const r1 = buf1->pubsync();
        int const r2 = buf2->pubsync();
        return (r1 == 0 && r2 == 0) ? 0 : -1;
    }

private:
    streambuf* buf1;
    streambuf* buf2;
};

// Helper function to create an ostream that outputs to both cout and a file
ostream& dual_output(ostream& os, ostream& file) {
    static dual_streambuf buf(os.rdbuf(), file.rdbuf());
    static ostream dual_stream(&buf);
    return dual_stream;
}

// Operator overloading for << sign that will output whole simulation to both Terminal and Output file
ostream& operator<< (ostream &out, Battlefield &battlefield) {
    battlefield.StartSimulation(out);        // Call StartSimulation() and pass out as the reference for ostream
    return out;                             // which means all out in StartSimulation() will replace cout
}

// ---------- Class OutputDisplay ----------
class OutputDisplay
{
public:
    // Output file stream
    ofstream outfile;

    // Constructor: Open output file
    OutputDisplay()
    {
        outfile.open("fileOutput1.txt");
        if (!outfile.is_open())
        {
            cout << "Error: Unable to open output file.\n";
        }
    }

    // Function to print to both terminal and file
    void printTerminalFile(Battlefield &data)
    {
        dual_streambuf dualBuf(cout.rdbuf(), outfile.rdbuf());
        ostream dualStream(&dualBuf);
        dualStream << data;     // Operator overloading << take place here
    }

    // Destructor: Close output file
    ~OutputDisplay()
    {
        if (outfile.is_open())
        {
            outfile.close();
        }
    }
};



#endif // BATTLEFIELD_H_INCLUDED
