#ifndef LINKEDLIST_H_INCLUDED
#define LINKEDLIST_H_INCLUDED
#include<vector>
#include<utility>
#include "Queue.h"


using namespace std;

template<typename T, typename U>
class robotActionList
{
public:
    struct node{
        T id;
        U lives =3;
        U numofkills=0;
        U posX;
        U posY;
        node* next;
    };

    node *head;
    node *tail;
    node* current;
    int sz;

    // Initialise head and tail to nullptr, size of list = 0
    robotActionList() : head(nullptr), tail(nullptr), sz(0) {}

    void *getNew(T id,U x,U y);
    void *movetoend();
    void push_back1(T id,U x,U y);
    void push_back2(node *passednode);
    bool deleteNode(T id);
    void print(ostream& out);

    node* getRobotByPosition(U x, U y);

    int countrobot(const T& currentID);

    vector<pair<U,U>>getAllRobotPositions()
    {
        vector<pair<U,U>> positions;
        node* current=head;
        while(current->next != head){
            positions.push_back(make_pair(current->posX, current->posY));
            current = current->next;
        }
        if(current->next == head){
            positions.push_back(make_pair(current->posX, current->posY));
        }
        return positions;
    }


    void moveToNext();
    void getCurrentRobot(T &id, U &x, U &y);
    int countRobotNum();

    ~robotActionList(){};

};

// Function to count total num of nodes(robots) alive/in linkedlist
template<typename T, typename U>
int robotActionList<T, U>::countRobotNum()
{
    if (head == nullptr) return 0;

    int robotCount = 1;     // Since ald checked head != nullptr, so start count from head =1
    node* current = head->next;
    while (current != head)
    {
        robotCount ++;           // +1 for every node(robot) count
        current = current->next; // change to next node
    }
    return robotCount;
}

// Function to count robot that have same robot type with parameter robot type
template<typename T, typename U>
int robotActionList<T, U>::countrobot(const T& currentID)
{
    node* cur = head;
    if (cur == nullptr)
    {
        return 0;
    }
    int foundcount=0;
    do{
        string robotType = cur->id.substr(0,2);
        if(robotType == currentID){
            cout << cur->id << endl;
            foundcount++;
        }
        cur=cur->next;
    }while(cur!= head);

    return foundcount;
}

// Function to create new node
template<typename T, typename U>
void* robotActionList<T, U>::getNew(T robotid, U x, U y) {
    node *newNode = new node;

    newNode->id = robotid;
    newNode->posX = x;
    newNode->posY= y;
    newNode->next = nullptr;

    return newNode;
}

// Function to insert new node into end of linked list
template<typename T, typename U>
void robotActionList<T, U>::push_back1(T robotid, U x, U y){
    node *newNode = static_cast<node*>(getNew(robotid, x,y));

    sz++;

    if(head == nullptr)   // If empty list
    {
        head = newNode;   // head and tail will be new node
        tail = newNode;
        newNode -> next = head;     // new node next pointer points to head (itself)
    }
    else
    {
        // If not empty, the (ori)last node/ tail's next points to new node, then new tail bcm new node, then new node tail point to head
        tail->next = newNode;
        tail = newNode;
        tail->next = head; //circular node
    }
}

//Function to insert node to end of linked list when revive robot
template<typename T, typename U>
void robotActionList<T, U>::push_back2(node* passedNode) {
    if (passedNode == nullptr) {
        return;
    }

    sz++;

    if (head == nullptr) {
        head = tail = passedNode;
        passedNode->next = head;
    } else {
        tail->next = passedNode;     // Same logic: change prev last node to new node inserted, then change next pointer
        tail = passedNode;
        tail->next = head;
    }
}

// Function to move to last node (not used)
template<typename T, typename U>
void* robotActionList<T, U>::movetoend(){
    tail= head;

    while(tail->next != head){
        tail = tail->next;
    }

     return tail;
}

// Function to print out all nodes' data
template<typename T, typename U>
void robotActionList<T, U>::print(ostream& out){

    if(head == nullptr){
        out << "List is empty.\n";
        return;
    }

    node *ptr = head;    // Initialise temp/ptr to head
    do{                 // Then start loop through all elements and print out until ptr == head again then stop
        out << ptr->id << " (" << ptr->posX << "," << ptr->posY << ")\n";
        ptr = ptr->next;    // go to next node
    }while(ptr != head);
}

// Function to get robotID by matching position x,y
template<typename T, typename U>
typename robotActionList<T, U>::node* robotActionList<T, U>::getRobotByPosition(U x, U y) {
     if (head == nullptr) {
            return nullptr; // List is empty
        }

        node* temp = head;
        do {    // Check if the value of x,y in current node == values of passed x,y
            if (temp->posX == x && temp->posY == y) {

                return temp; // Found matching position, return node
            }
            temp = temp->next;  // go to next node
        } while (temp != head);

        return nullptr; // Position not found in the list
}

// function to move to next node (not used)
template<typename T, typename U>
void robotActionList<T, U>::moveToNext() {
    if (current != nullptr) {
        current = current->next;
    }
}

// Function to get current robot (not used)
template<typename T, typename U>
void robotActionList<T, U>::getCurrentRobot(T &id, U &x, U &y) {
    if (current != nullptr) {
        id = current->id;
        x = current->posX;
        y = current->posY;
    }else{
        cout << "current not available.\n";
    }
}

// Function to delete node based on passed robotID
template<typename T, typename U>
bool robotActionList<T, U>::deleteNode(T id)
{
    if (head == nullptr) return false; // If list is empty, return false

    node* prev = nullptr;
    node* cur = head;
    do {
        if (cur->id == id) break; // Found the node to delete
        prev = cur;
        cur = cur->next;
    } while (cur != head); // Traverse until we loop back to the head

    if (cur->id != id) return false; // Node with given id not found

    // If the node to delete is the head node
    if (cur == head)
    {
        // If head is the only node in the list
        if (head->next == head) {
            head = nullptr;
            tail = nullptr;
        }
        else
        {
            // Find the last node and adjust pointers
            node* temp = head;
            while (temp->next != head)
            {
                temp = temp->next;
            }
            head = head->next;
            temp->next = head;
            if (tail == cur)
            {
                tail = temp;
            }
        }
    }
    else
    {
        // Node to delete is not the head
        prev->next = cur->next;
        if (tail == cur)
        {
            tail = prev;
        }
    }

    sz--; // Decrease size of the list
    delete cur; // Delete the node
    return true;
}





#endif // LINKEDLIST_H_INCLUDED
