#ifndef QUEUE_H_INCLUDED
#define QUEUE_H_INCLUDED
#include "LinkedList.h"

#include <iostream>
using namespace std;

template<typename T, typename U>
class DeadRobotQueue
{
public:
    struct DeadRobotnode{
        T id;
        U lives =3;
        U posX;
        U posY;
        DeadRobotnode* next;
    };

    DeadRobotnode *front;
    DeadRobotnode *rear;
    int sz;

    // Initialise front and rear to nullptr , size of queue = 0
    DeadRobotQueue() {
        sz = 0;
        front = rear = nullptr;
    }

    int countrobot1(const T& currentID);
    void enqueue(DeadRobotnode* passednode);
    DeadRobotnode* dequeue();
    bool isEmpty();
    void print(ostream& out);

    ~DeadRobotQueue(){
        sz=0;
        while(!isEmpty()){
            dequeue();
        }

    }
protected:
};

// Function to check whether queue is empty
template<typename T, typename U>
bool DeadRobotQueue<T, U>::isEmpty(){
    if (front == nullptr){
        return true;
    }else{
        return false;
    }
}

// Function to count robot that have same type with parameter robot type in both queues (waiting and endgame)
template<typename T, typename U>
int DeadRobotQueue<T, U>::countrobot1(const T& currentID)
{
    DeadRobotnode* cur = front;
    if (cur == nullptr)   // If queue empty
    {
        return 0;     // return 0 count
    }

    int foundcount = 0;
    while (cur != nullptr)
    {
        string robotType = cur->id.substr(0, 2);    // Get substr of first 2 char of robotID in each node to check robot type
        if (robotType == currentID)     // If, same, counter+1
        {
            foundcount++;
        }
        cur = cur->next;      // go to next node
    }

    return foundcount;   // return count value to variable after finish counting
}

//  Function to enqueue/add new node to end of queue
template<typename T, typename U>
void DeadRobotQueue<T, U>::enqueue(DeadRobotnode* passednode) {
    if (passednode == nullptr) {
        return;
    }

    passednode->next = nullptr;   // set passednode next pointer to nullptr, as it will be new last/rear node

    if (isEmpty()) {
        front = passednode;   // If queue empty, front and rear = passednode
        rear = front;
    }else{
        rear->next = passednode;    // Set prev rear node next point to passednode
        rear = rear->next;         // Set new rear = passednode
    }
    sz ++;   // Add queue size by 1
}

// Function to dequeue first/front node from queue (used in waiting robot queue/ deadrobot(obj name in coding))
template<typename T, typename U>
typename DeadRobotQueue<T, U>::DeadRobotnode* DeadRobotQueue<T, U>::dequeue() {
    if (!isEmpty()) {
        DeadRobotnode *p = front;
        front = front->next;
        if (front == nullptr) { // If the queue is now empty, set rear to nullptr as well
            rear = nullptr;
        }
        sz--;
        return p; // Return the dequeued node pointer
    } else {
        cout << "Queue is empty\n";
        return nullptr;
    }
}

// Function to print all nodes' data
template<typename T, typename U>
void DeadRobotQueue<T, U>::print(ostream& out){
     if(front == nullptr){
        out << "Queue is empty.\n";   // If queue empty, output msg stating queue is empty
        return;
    }

    DeadRobotnode *ptr = front;  // Initialise temp/ptr node to front (start from first node)
    while (ptr != nullptr) {    // Loop through each node and print their data until ptr = nullptr (last/rear node)
        out << ptr->id << " (" << ptr->posX << "," << ptr->posY << ")\n";
        ptr = ptr->next;   // go to next node in queue
    }
}


#endif // QUEUE_H_INCLUDED
