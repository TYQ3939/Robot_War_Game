/*
*****************************************************************************
 Program: main.cpp
 Course: CCP6124 OOPDS
 Lecture Class: TC3L
 Tutorial Section: T12l, T11L
 Trimester; 2410
 Member1: 1211112187 | Eng Zi Ying   | 1211112187@student.mmu.edu.my | 013-6883338  |
 Member2: 1211108242 | Tan Chee Yee  | 1211108242@student.mmu.edu.my | 011-10968670 |
 Member3: 1211108855 | Teh Yu Qian   | 1211108855@student.mmu.edu.my | 016-3210241  |
 Member4: 1231302923 | Teow Wei Ting | 1231302923@student.mmu.edu.my | 011-10806156 |
 ****************************************************************************
 Task Distribution:
 Member1: Seeing Robot, Robocop, Terminator, Linked list and Queue
 Member2: Moving Robot, Terminator Robocop, BlueThunder, battlefield and robot
 Member3: Shooting Robot, UltimateRobot, battlefield and robot
 Member4: Stepping Robot, Madbot, robotank, Linked list and Queue

*****************************************************************************
*/



#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cmath>
#include <cctype>
#include <cstdlib>
#include <ctime>
#include <tuple>
#include <set>

// include all header files
#include "Battlefield.h"
#include "Robot.h"
#include "LinkedList.h"
#include "Queue.h"

using namespace std;

// ----------------------------------------- Main function -----------------------------------------
int main()
{
    //robotActionList<string, int> robotActions;

    // Create an object of class Battlefield
    Battlefield battlefield;
    battlefield.ReadFile();         // call RedFile() to read input file

    // Create an object of class OutputDisplay
    OutputDisplay output;
    output.printTerminalFile(battlefield);        // output results to both terminal and output file

    return 0;
}

// ----------------------------------------- (Battlefield) ReadFile function -----------------------------------------
int Battlefield::ReadFile()
{
    // Declare input file stream
    ifstream infile;

    // Open input file
    infile.open("fileInput1.txt");
    // Check for failure in opening input file
    if (infile.fail())
    {
        cout << "Error message: file is not found\n";   // Output error msg stating file is not found
        return EXIT_FAILURE;
    }

    // String variable to store each line read from the input file
    string line;

    // Reading each line from the input file and processing instructions
    while (getline(infile, line) && !(line.empty() || line == "\n"))
    {
        // Break down instruction using string stream
        istringstream ss(line);
        string operand1;
        ss >> operand1;

        if (operand1 == "M")
        {
            ss >> operand1 >> operand1;
            ss >> cols >> rows;         // M = cols (x-grid) , N = rows (y-grid)

            // Create a dynamic multidimensional array (for here 2d array of m x n that can change size based on value of m,n read from input file)
            grid = new string*[rows];        // int** grid means that it is a pointer that points to an array that stores pointers that points to arrays that stores num of rows of elements
            for (int i = 0; i < rows; i++ )             // (technically first element's address which actually represents the whole array)
            {
                grid[i] = new string[cols];           // for each row array stores num of cols of elements
            }

            // Initialise all elements in array to be "NULL"
            for (int i=0; i<rows; i++)               // for every row in the array
            {
                for (int j = 0; j < cols; j++)      // for every col in each row
                {
                    grid[i][j] = "NULL";           // M = cols (x/j), N = rows (y/i)
                }
            }
        }
        else if (operand1 == "turns:")
        {
            ss >> turn;     // get total num of turns for simulation
        }
        else if (operand1 == "robots:")
        {
            ss >> robotNum;     // get total num of robots
        }
        else if (operand1 == "RoboCop" || operand1 == "Terminator" || operand1 == "TerminatorRoboCop" ||operand1 == "BlueThunder" || operand1 == "MadBot" || operand1 == "RoboTank" ||
                 operand1 == "UltimateRobot")    // if the first word of the line is these above, means they are robots
        {
            string robotID, xstr, ystr;
            int x, y;
            ss >> robotID >> xstr >> ystr;
            robotID= robotID.substr(0,4);   // display only the robot id without the name

            if (xstr== "random" && ystr=="random")
            {
                // Store details of randomly placed robot
                randomRobots.push_back(make_tuple(robotID, xstr, ystr));

            }
            // Check whether the coordinates from file is in range
            else if ((stoi(xstr)>=0 && stoi(xstr)< cols) && (stoi(ystr)>=0 && stoi(ystr)< rows))
            {
                x= stoi(xstr);
                y= stoi(ystr);
                PlaceRobot(robotID, x, y);      // Call PlaceRobot() to insert each robot into their respective location

                //Insert into LinkedList(robotid and position)
                robotActions.push_back1(robotID,x,y);
            }
            else
            {
                cerr<< "Invalid input : random\n ";        // Output error if not fulfill above requirements
            }
        }

    }
    infile.close();     // Close input file after finish reading all lines
     // After placing all other robots, place randomly generated robots
    bool checkPassed= false;
    randomRobotGenerator(checkPassed);
    return 0;
}

// ----------------------------------------------------- (Battlefield) Place Robot ----------------------------------------------------------
void Battlefield::PlaceRobot(string &robotID, int x, int y)
{
    string gridRobotID;
    if (robotID.size() < initialLength)
    {
        gridRobotID = robotID + string(initialLength - robotID.size(), ' ');
    }

    if (x >= 0 && x < cols && y >= 0 && y < rows)
    {
        grid[y][x]= gridRobotID; // Place the robot ID string at the specified position
    }                        // grid[y][x] bcs the format is grid[rows][cols] which rows = y, cols = x
    else
    {
         cerr << "Position out of bounds" << endl;
    }
}

// ----------------------------------------------------- (Battlefield) Display Battlefield ----------------------------------------------------------
void Battlefield::DisplayBattlefield(ostream &out)
{
    // Output memory indices
    for (int j = 0; j < cols; j++)
    {
        out << "     " << setw(2) << setfill(' ') << j << setw(2);
    }
    out << endl;

    // Output memory contents
    for (int i = 0; i < rows; i++)
    {
        out<< "     +";
        for (int j = 0; j < cols; j++)
        {
            out<< "------+";
        }
        out << endl;
        out << setw(2) << setfill('0') << i << "   |";

        for (int j = 0; j < cols; j++)
        {
            if (grid[i][j] == "NULL")
            {
                out << "      " << "|";      // if the value of current element is "NULL", output "       " as empty slot
            }
            else
            {
                out << grid[i][j] << "|";   // If there's robot at the specific location, output the robotID
            }
        }
        out << endl;
        out << "     +";
        for (int j = 0; j < cols; j++)
        {
            out<< "------+";
        }

        out << endl;
    }
    out << endl;
}

// ----------------------------------------------------- (Battlefield) Start Simulation ----------------------------------------------------------
void Battlefield::StartSimulation(ostream &out)
{
    // Display robot actions
    if(robotActions.head == nullptr)
    {
        out << "No robots to execute actions.\n";   // if the first element of LinkedList = nullptr, meaning there's no element in the list
        return;
    }

    // Initialise the current node to the head of LinkedList (first element) b4 simulation starts
    robotActionList<string, int>::node *current = robotActions.head;
    //create a new robotaction node to store the revive robot back to the action list

    for (int i = 0; i < turn+1; i++)    // while in turns
    {
        if (robotNum != 1)      // While total num of robots not left one
        {
            if (i == 0)
            {
                out << "Robot initial position: \n";
                DisplayBattlefield(out);    // Display all robots original position
                out << endl << "-----------------------------------------------------------------------------------------" << endl << endl;
            }
            else
            {
                // Display turn
                out << "Turn: " << i << endl;
                //out << endl << "Robot Num: " << robotNum << endl;

                // if queue != empty, placerobot() > for reviving the robot (remainder! place only 1 robot)
                robotActionList<string, int>::node *reviverobot = new robotActionList<string, int>::node();
                if(!deadrobot.isEmpty())
                {
                    auto* dequeuedRobot = deadrobot.dequeue();
                    reviverobot->id = dequeuedRobot->id;
                    reviverobot->lives = dequeuedRobot->lives;
                    reviverobot->numofkills = 0;     // penalty for dead robots;
                    bool checkPassed=true;
                    reviverobot->posX = getRandX(checkPassed);
                    reviverobot->posY = getRandY(checkPassed);
                    // check if the linked list is empty. if yes, the revive robot is the head
                    if (robotActions.sz != 0)
                    {
                        robotActions.tail->next = reviverobot;
                        robotActions.tail = reviverobot;
                        reviverobot->next = robotActions.head;
                    }
                    else
                    {
                        reviverobot = robotActions.head = robotActions.tail;
                        reviverobot->next = robotActions.head;
                    }

                    // dequeue the robot
                    if(reviverobot)
                    {
                        robotActions.push_back2(reviverobot);   // Push back to linked list
                        PlaceRobot(reviverobot->id, reviverobot->posX, reviverobot->posY);      // Place robot in grid
                        out << endl << reviverobot->id << " reentering the battlefield at (" << reviverobot->posX << "," << reviverobot->posY << ")\n" ;

                        delete dequeuedRobot; // free memory
                    }
                }

                // Execute the robot's action based on its ID
                out << endl << "LinkedList Robots: " << endl;
                robotActions.print(out);
                out << endl << "Waiting Robots Queue: " << endl;
                deadrobot.print(out);
                out << endl << "End Game(Dead) Robots Queue: " << endl;
                endGameRobot.print(out);
                out << endl << "-----------------------------------" << endl << endl;

                string robotID = current->id;       // get current robot's id & position
                int x = current->posX;
                int y = current->posY;
                int lives = current->lives;

                // Display the ID and lives of each robot in the list
                out << "Robot " << robotID << " at (" << x << "," << y <<") action, Lives: " << lives << endl<< endl;


                // Create an object of respective robot type, then call the robot's action
                if (robotID.find("RC") != string::npos) // eg if find substr "RC" from the string current robotID --
                {
                    RoboCop robot(robotID, x, y);      // -- create an object of Robocop and initialise robotID & position with current ones
                    robot.actions(*this, robotActions, deadrobot, endGameRobot, out);             // Then call the function actions and pass as parameter *this --
                    out << endl;                     // -- which is a reference to current battlefield object
                }                                         // (since StartSimulation() is a member function)
                else if (robotID.find("TT") != string::npos)
                {
                    Terminator robot(robotID, x, y);
                    robot.actions(*this, robotActions,deadrobot, endGameRobot,out);         // other else if with same logic...
                    out << endl;
                }
                else if (robotID.find("TR") != string::npos)
                {
                    TerminatorRoboCop robot(robotID, x, y);
                    robot.actions(*this, robotActions,deadrobot, endGameRobot,out);
                    out << endl;
                }
                else if (robotID.find("BT") != string::npos)
                {
                    BlueThunder robot(robotID, x, y);
                    robot.actions(*this, robotActions,deadrobot, endGameRobot,out);
                    out << endl;
                }
                else if (robotID.find("MB") != string::npos)
                {
                    MadBot robot(robotID, x, y);
                    robot.actions(*this, robotActions,deadrobot, endGameRobot,out);
                    out << endl;
                }
                else if (robotID.find("RT") != string::npos)
                {
                    RoboTank robot(robotID, x, y);
                    robot.actions(*this, robotActions,deadrobot, endGameRobot,out);
                    out << endl;
                }
                else if (robotID.find("UR") != string::npos)
                {
                    UltimateRobot robot(robotID, x, y);
                    robot.actions(*this, robotActions,deadrobot, endGameRobot,out);
                    out << endl;
                }

                current = current->next;    // Set current node to next node

                DisplayBattlefield(out);   // Display battlefield to show changes
                robotNum = robotActions.countRobotNum();    // Calculate num of remaining robots in battlefield (linked list)

                out << endl << "-----------------------------------------------------------------------------------------" << endl << endl;
            }
        }
        else
        {
            // Display result when remain 1 robot
            out << "\n  ---------------------- Simulation End by Remaining 1 Robot ---------------------- " << endl;
            out << "\nTotal Turns Ran: " << i << endl;
            out << "\nRemaining Robot: " << current->id << endl;
            out << "\nLinkedList Robot:" << endl;
            robotActions.print(out);
            out << "\nWaiting Robots Queue: " << endl;
            deadrobot.print(out);
            out << "\nEnd Game(Dead) Robots Queue: " << endl;
            endGameRobot.print(out);
            out << endl;
            exit(0);    // Program completted
        }
    }
    // Display result when turn finish
    out << "\n       ---------------------- Simulation End by Times Up ---------------------- " << endl;
    out << "\nTotal Turns Ran: " << turn << endl;
    out << "\nLinkedList Robot:" << endl;
    robotActions.print(out);
    out << "\nWaiting Robots Queue: " << endl;
    deadrobot.print(out);
    out << "\nEnd Game(Dead) Robots Queue: " << endl;
    endGameRobot.print(out);

}

