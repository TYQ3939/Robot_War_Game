#ifndef ROBOT_H_INCLUDED
#define ROBOT_H_INCLUDED
#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <cmath>
#include <cctype>
#include <cstdlib>
#include <ctime>
#include <tuple>
#include "LinkedList.h"
#include "Queue.h"

using namespace std;

// ---------- base class Robot (grandparent) ----------
class Robot
{
protected:
    int robotPosX = -1;
    int robotPosY = -1;
	string id_ = "";

	int x_;
	int y_;

	int numOfLives = 3;
	int numOfKills = 0;
    mutable vector<pair<int, int>> possibleMoves;      // Initialise list to store possible moves when robot looks
    mutable vector<pair<int, int>> enemylist;         // Initialise list to store enemy spotted when robot looks

public:

	Robot(string id="RR-1",int x=0,int y=0): id_(id), robotPosX(x), robotPosY(y) {}     // initialize default value to member variable of object, --
                                                                                       // -- if there's a given value, pass the argument to the member variable (refer to after the : )
	virtual ~Robot() {}

	string getid() const {return id_; }
	void setId(const string& id) { id_=id; }

	int x ( ) {return x_; }
	void setX(int x) {x_= x; }

	int y ( ) { return y_; }
	void setY(int y) {y_ = y; }

	// Pure virtual function that the 7 grandchild robot classes need to implement
	virtual void actions(Battlefield& battlefield, robotActionList<string, int> &robotActions, DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) = 0;      // pure virtual function that the grandchild classes must inherit

	// Update position in the linked list (only actions step and move involve)
    void updatePosition(robotActionList<string, int> &robotActions, int x, int y)
    {
        robotPosX = x;
        robotPosY = y;

        // Find the node with the current robotID and update its position
        auto current = robotActions.head;
        do {
            if (current->id == id_)
            {
                current->posX = x;
                current->posY = y;
                break;
            }
            current = current->next;
        } while (current != robotActions.head);
    }
};

// ------------------------ Subclass 1 SeeingRobot, MovingRobot, ShootingRobot, SteppingRobot (parent) ------------------------
class SeeingRobot: virtual public Robot
{
private:

public:
    SeeingRobot(){};
    virtual ~SeeingRobot(){};
    virtual void actionLook(const Battlefield& battlefield,ostream& out) const = 0;   // pure virtual function that the grandchild(derived) classes must inherit

};

class MovingRobot: virtual public Robot
{
private:

public:
    MovingRobot(){};
    virtual ~MovingRobot(){};
    virtual void actionMove( Battlefield& battlefield,  robotActionList<string, int> &robotActions,ostream& out) = 0;     // pure virtual function that the grandchild(derived) classes must inherit

};

class ShootingRobot: virtual public Robot
{
private:

public:

    ShootingRobot(){};
    virtual ~ShootingRobot(){};
    virtual void actionFire(Battlefield& battlefield,  robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) = 0;    //pure virtual function that the grandchild(derived) classes must inherit
};

class SteppingRobot: virtual public Robot
{
private:

public:
    SteppingRobot(){};
    virtual ~SteppingRobot(){};
    virtual void actionStep(Battlefield& battlefield,  robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) = 0;    // pure virtual function that the grandchild(derived) classes must inherit
};




// ------------------------------- Sub-subclass 7 Types of Robot (grandchild) -------------------------------


// ------------------------------------------- Class RoboCop -------------------------------------------
class RoboCop: public SeeingRobot, public MovingRobot, public ShootingRobot    // RoboCop inherits from these 3 parent classes while having properties of grandparent class Robot
{
private:

    int check = -1;
    int listrobotcount,deadrobotcount,endrobotcount;
    string changedId, newid, newRobotType;

public:

    RoboCop(string id,int x, int y ) : Robot(id, x,y) {}   // Initialise robotID and position when creating an object with passed parameter value

    void actionLook(const Battlefield& battlefield, ostream& out) const override
    {
        out << "RoboCop actionLook" << endl;
        for (int i=-1; i<2; i++)
        {
            for (int j=-1; j<2; j++)
            {
                if(i==0  && j==0)
                {
                    continue;
                }
                else
                {
                    int lookPosX = robotPosX + j;
                    int lookPosY = robotPosY + i;

                   // cout << lookPosX << "   " << lookPosY << endl;


                    if (lookPosX >= 0 && lookPosX < battlefield.cols && lookPosY >= 0 && lookPosY < battlefield.rows)
                    {
                        if (battlefield.grid[lookPosY][lookPosX] != "NULL")
                        {
                            out << "enemy spotted on  (" << lookPosX << "," << lookPosY << ")." << endl;
                        }
                        else
                        {
                            possibleMoves.push_back({lookPosX, lookPosY});
                            continue;
                        }
                    }
                }
            }
        }
        out << endl;
    }

    virtual void actionMove(Battlefield& battlefield,  robotActionList<string, int> &robotActions,ostream& out) override
    {
        out << "RoboCop actionMove" << endl;
        // Check whether theres moves to choose from
        if (possibleMoves.empty()) {
            out << "No moves to make." << endl;
            return;
        }
        // If yes, choose one of the position randomly from the possible moves
        pair<int, int> chosenMove = possibleMoves[rand() % possibleMoves.size()];

        battlefield.setposition(robotPosX, robotPosY);
        updatePosition(robotActions, chosenMove.first, chosenMove.second);  // Update robot position in grid
        check=1;
        battlefield.updateRobotPosition(id_, robotPosX, robotPosY,check); // Modify Battlefield state indirectly
        out << "Moved to (" << robotPosX << "," << robotPosY << ")." << endl;
        out << endl;
    }

    virtual void actionFire(Battlefield& battlefield, robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) override
    {
        out << "RoboCop actionFire" << endl;
        for (int i = 0; i < 3; ++i)
        {
            int x, y;
            int firePosX, firePosY;
            do {
                x = (rand() % 21) - 10;  // Random value between -10 and 10
                y = (rand() % 21) - 10;  // Random value between -10 and 10
                firePosX = robotPosX + x;
                firePosY = robotPosY + y;
            } while (abs(x) + abs(y) < 1 || abs(x) + abs(y) > 10 ||
                    (firePosX == robotPosX && firePosY == robotPosY) ||
                    firePosX < 0 || firePosX >= battlefield.cols ||
                    firePosY < 0 || firePosY >= battlefield.rows);

            if (battlefield.grid[firePosY][firePosX] != "NULL")
            {
                out << "Hit! Robot at (" << firePosX << "," << firePosY << ")." << endl;

                string targetRobotID;
                battlefield.setposition(robotPosX, robotPosY);

                // Get target robotID by position
                auto killrobot = robotActions.getRobotByPosition(firePosX, firePosY);
                if (killrobot != nullptr)
                {
                    targetRobotID = killrobot->id;
                }

                // Convert robotActionList node to DeadRobotQueue node
                DeadRobotQueue<string, int>::DeadRobotnode* newNode = new DeadRobotQueue<string, int>::DeadRobotnode();
                newNode->id = killrobot->id;
                newNode->lives = killrobot->lives;
                newNode->posX = killrobot->posX;
                newNode->posY = killrobot->posY;
                newNode->next = nullptr;

                // enemy node live -1
                newNode->lives -=1;

                //check if live <=0, if yes then pass ;if no,enemy node past to queue list
                if(newNode->lives <= 0)
                {
                    out << targetRobotID << " no more lives... End of robot " << targetRobotID << endl;
                    endGameRobot.enqueue(newNode);
                }
                else
                {
                    out <<  targetRobotID << " remains " << newNode->lives << " lives \n";
                    out << targetRobotID << " enters the queue waiting to be revived ...\n";
                    deadrobot.enqueue(newNode);
                }
                // delete the enemy node from linkedlist
                robotActions.deleteNode(targetRobotID);

               //Upgrade robot
                auto currentrobot = robotActions.getRobotByPosition(robotPosX, robotPosY);   // get current robot
                currentrobot->numofkills++;     // add kill count

               // Check if robot kill count >= 3 ?
                if(currentrobot->numofkills <3)
                {
                    // If havent >= 3, output msg +1 kill count
                    out << currentrobot->id << " kill count +1... Total kill count = " <<currentrobot->numofkills<< endl;
                }
                else
                {
                    out << currentrobot->id  <<" upgraded! Upgrading to TerminatorRoboCop...\n";
                    newRobotType = "TR"; //get the old id to change to new id
                    // count how many robots with same robot type in linkedlist and queues(maybe will have same type robot that is dead at the moment)
                    listrobotcount = robotActions.countrobot(newRobotType);
                    deadrobotcount = deadrobot.countrobot1(newRobotType);
                    endrobotcount = endGameRobot.countrobot1(newRobotType);

                    int newrobotcount = listrobotcount + deadrobotcount + endrobotcount+1;

                    if(newrobotcount<10)
                    {
                        id_= "TR0" + to_string(newrobotcount);     // +1 to previous robot count since new robot for that type
                    }
                    else
                    {
                        id_= "TR" + to_string(newrobotcount);
                    }
                    out << currentrobot->id << " ==> " << id_ << endl;
                }

                currentrobot->id = id_;  // Update linked list robotID
                check=0;
                battlefield.updateRobotPosition(id_, firePosX, firePosY, check); // Modify Battlefield state indirectly
            }
        }
        out << endl;
    }

    void actions(Battlefield& battlefield, robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot, ostream &out) override   // actions() will call all action function of each respective class
    {
        actionLook(battlefield, out);
        actionMove(battlefield, robotActions,out);
        actionFire(battlefield, robotActions, deadrobot, endGameRobot,out);
    }

    ~RoboCop(){};

};


// // ------------------------------------------- Class Terminator -------------------------------------------
class Terminator:public SeeingRobot, public SteppingRobot
{
private:
int check= 0;
int listrobotcount,deadrobotcount,endrobotcount;
string changedId, newid, newRobotType;

public:

    Terminator(string id,int x, int y ) : Robot(id, x,y) {}

    virtual void actionLook(const Battlefield& battlefield, ostream& out)const override
    {
        out << "Terminator actionLook" << endl;

        for (int i=-1; i<2; i++)
        {
            for (int j=-1; j<2; j++)
            {
                if(i==0  && j==0)
                {
                    continue;
                }
                else
                {
                    int lookPosX = robotPosX + j;
                    int lookPosY = robotPosY + i;

                    if (lookPosX >= 0 && lookPosX < battlefield.cols && lookPosY >= 0 && lookPosY < battlefield.rows)
                    {
                        if (battlefield.grid[lookPosY][lookPosX] != "NULL")
                        {
                            out << "enemy spotted on (" << lookPosX << "," << lookPosY << ")." << endl;
                            enemylist.push_back({lookPosX, lookPosY});     // If theres robot in looked position, insert position into enemy list
                        }
                        else
                        {
                            possibleMoves.push_back({lookPosX, lookPosY});  // If no robots, store as possible moves
                            continue;
                        }
                    }
                }
            }
        }
        out << endl;

    }


    virtual void actionStep(Battlefield& battlefield,  robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) override
    {
        out << "Terminator actionMove" << endl;
        string targetRobotID;

        // Check whether there's enemy spotted?
        if (enemylist.empty())
        {
            if (possibleMoves.empty())
            {
                out << "No moves to make." << endl;
                return;
            }
            // If no enemy spotted, randomly choose a position to move from possible moves list
            pair<int, int> chosenMove = possibleMoves[rand() % possibleMoves.size()];
            battlefield.setposition(robotPosX, robotPosY);
            updatePosition(robotActions, chosenMove.first, chosenMove.second);   // Update position in linkedlist after move
            check=1;
            battlefield.updateRobotPosition(id_, robotPosX, robotPosY,check); // Modify Battlefield state indirectly
            out << "Moved to (" << robotPosX << "," << robotPosY << "). No enemy killed." << endl;
            return;
        }
        else       // If theres enemy spotted
        {
            pair<int, int> chosenMove = enemylist[rand() % enemylist.size()];
            battlefield.setposition(robotPosX, robotPosY);

            // Get target robotID by position
            auto killrobot = robotActions.getRobotByPosition(chosenMove.first , chosenMove.second);
            if (killrobot != nullptr)
            {
                targetRobotID = killrobot->id;
                out << "Moved to (" << chosenMove.first << "," << chosenMove.second << "). Terminated robot "  << targetRobotID << endl;
            }
            else
            {
                out << "No robot found at position (" << chosenMove.first << "," << chosenMove.second << ")." << endl;
            }

            // Convert robotActionList node to DeadRobotQueue node
            DeadRobotQueue<string, int>::DeadRobotnode* newNode = new DeadRobotQueue<string, int>::DeadRobotnode();
            newNode->id = killrobot->id;
            newNode->lives = killrobot->lives;
            newNode->posX = killrobot->posX;
            newNode->posY = killrobot->posY;
            newNode->next = nullptr;

            updatePosition(robotActions, chosenMove.first, chosenMove.second);
            // enemy node live -1
            newNode->lives -=1;

            //check if live <=0, if yes then pass ;if no,enemy node past to queue list
            if(newNode->lives <= 0)
            {
                out << targetRobotID << " no more lives... End of robot " << targetRobotID << endl;
                endGameRobot.enqueue(newNode);
            }
            else
            {
                out <<  targetRobotID << " remains " << newNode->lives << " lives \n";
                out << targetRobotID << " enters the queue waiting to be revived ...\n" ;
                deadrobot.enqueue(newNode);
            }
             // delete the enemy node
            robotActions.deleteNode(targetRobotID);

            //Upgrade robot
            auto currentrobot = robotActions.getRobotByPosition(robotPosX, robotPosY);   // get current robot
            currentrobot->numofkills++;     // add kill count

           // Check if robot kill count >= 3 ?
            if(currentrobot->numofkills <3)
            {
                // If havent >= 3, output msg +1 kill count
                out << currentrobot->id << " kill count +1... Total kill count = " <<currentrobot->numofkills<< endl;
            }
            else
            {
                out << currentrobot->id  <<" upgraded! Upgrading to TerminatorRoboCop...\n";
                newRobotType ="TR"; //get the old id to change to new id
                // Count how many robots with same robot type in linkedlist and queues(maybe will have same type robot that is dead at the moment)
                listrobotcount = robotActions.countrobot(newRobotType);
                deadrobotcount = deadrobot.countrobot1(newRobotType);
                endrobotcount = endGameRobot.countrobot1(newRobotType);
                // Add all counts with same robot type in linkedlist and 2 queues
                int newrobotcount = listrobotcount + deadrobotcount + endrobotcount+1;  // +1 to previous robot count since new robot for that type
                if(newrobotcount<10)
                {
                    id_= "TR0" + to_string(newrobotcount);
                }
                else
                {
                    id_= "TR" + to_string(newrobotcount);
                }
                out << currentrobot->id << " ==> " << id_ << endl;
            }

            currentrobot->id = id_;   // Update linked list robotID
            check=1;
            battlefield.updateRobotPosition(id_, robotPosX, robotPosY,check); // Modify Battlefield state indirectly
            return;
        }
        out << endl;
    }

    virtual void actions(Battlefield& battlefield, robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream &out) override
    {
        actionLook(battlefield, out);
        actionStep(battlefield, robotActions,deadrobot, endGameRobot,out);
    }

    ~Terminator(){};
protected:
};


// -----------------------------------------------------------------------------
class TerminatorRoboCop:public SeeingRobot, public ShootingRobot, public SteppingRobot
{
private:
int check=-1;
int listrobotcount,deadrobotcount,endrobotcount;
string changedId, newid, newRobotType;

public:

    TerminatorRoboCop (string id,int x, int y ) : Robot(id, x,y) {}

    virtual void actionLook(const Battlefield& battlefield, ostream& out)const override
    {
        out << "TerminatorRoboCop actionLook" << endl;

        for (int i=-1; i<2; i++)
        {
            for (int j=-1; j<2; j++)
            {
                if(i==0  && j==0)
                {
                    continue;
                }
                else
                {
                    // Same look logic with Terminator: if spotted enemy in the position, store in to enemy list, else possible moves
                    int lookPosX = robotPosX + j;
                    int lookPosY = robotPosY + i;

                    if (lookPosX >= 0 && lookPosX < battlefield.cols && lookPosY >= 0 && lookPosY < battlefield.rows)
                    {
                        if (battlefield.grid[lookPosY][lookPosX] != "NULL")
                        {
                            out << "enemy spotted on (" << lookPosX << "," << lookPosY << ")." << endl;
                            enemylist.push_back({lookPosX, lookPosY});
                        }
                        else
                        {
                            possibleMoves.push_back({lookPosX, lookPosY});
                            continue;
                        }
                    }
                }
            }
        }
        out << endl;
    }

    virtual void actionFire(Battlefield& battlefield, robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) override
    {
        out << "TerminatorRoboCop actionFire" << endl;
        for (int i = 0; i < 3; ++i)
        {
            int x, y;
            int firePosX, firePosY;
            do {
                x = (rand() % 21) - 10;  // Random value between -10 and 10
                y = (rand() % 21) - 10;  // Random value between -10 and 10
                firePosX = robotPosX + x;
                firePosY = robotPosY + y;
            } while (abs(x) + abs(y) < 1 || abs(x) + abs(y) > 10 ||         // will loop until get x,y in range of rows cols
                    (firePosX == robotPosX && firePosY == robotPosY) ||     // and max fire range (x+y <= 10)
                    firePosX < 0 || firePosX >= battlefield.cols ||
                    firePosY < 0 || firePosY >= battlefield.rows);

            if (firePosX >= 0 && firePosX <= battlefield.cols && firePosY >= 0 && firePosY <= battlefield.rows)
            {
                out << "Firing at (" << firePosX << "," << firePosY << ")." << endl;
            }
            else       // To check if there's a out-of-range position slipped out
            {
                out << "Firing out of bounds at (" << firePosX << "," << firePosY << ")." << endl;
            }
            // If the position in grid is not empty = hit a robot!
            if (battlefield.grid[firePosY][firePosX] != "NULL")
            {
                out << "Hit! Robot at (" << firePosX << "," << firePosY << ")." << endl;

                string targetRobotID;
                battlefield.setposition(robotPosX, robotPosY);

                // Since only know hit a robot at that position, get target robotID by searching matched position in linkedlist
                auto killrobot = robotActions.getRobotByPosition(firePosX, firePosY);
                if (killrobot != nullptr)
                {
                    targetRobotID = killrobot->id;
                }

                // Convert robotActionList node to DeadRobotQueue node
                DeadRobotQueue<string, int>::DeadRobotnode* newNode = new DeadRobotQueue<string, int>::DeadRobotnode();
                newNode->id = killrobot->id;
                newNode->lives = killrobot->lives;
                newNode->posX = killrobot->posX;
                newNode->posY = killrobot->posY;
                newNode->next = nullptr;

                // enemy node live -1
                newNode->lives -=1;

                //check if live <=0, if yes then pass ;if no,enemy node past to queue list
                if(newNode->lives <= 0)
                {
                    out << targetRobotID << " no more lives... End of robot " << targetRobotID << endl;
                    endGameRobot.enqueue(newNode);
                }
                else
                {
                    out << targetRobotID << " remains " << newNode->lives << " lives \n";
                    out << targetRobotID << " enters the queue waiting to be revived ...\n";
                    deadrobot.enqueue(newNode);
                }

                // delete the enemy node
                robotActions.deleteNode(targetRobotID);

               //Upgrade robot
                auto currentrobot = robotActions.getRobotByPosition(robotPosX, robotPosY);   // get current robot
                currentrobot->numofkills++;     // add kill count

               // Check if robot kill count >= 3 ?
                if(currentrobot->numofkills <3)
                {
                    // If havent >= 3, output msg +1 kill count
                    out << currentrobot->id << " kill count +1... Total kill count = " <<currentrobot->numofkills<< endl;
                }
                else
                {
                    out << currentrobot->id  <<" upgraded! Upgrading to UltimateRobot...\n";
                    newRobotType = "UR";    //robot type that the robot will upgrade to
                    // count how many robots with same robot type in linkedlist and queues(maybe will have same type robot that is dead at the moment)
                    listrobotcount = robotActions.countrobot(newRobotType);
                    deadrobotcount = deadrobot.countrobot1(newRobotType);
                    endrobotcount = endGameRobot.countrobot1(newRobotType);

                    int newrobotcount = listrobotcount + deadrobotcount + endrobotcount + 1;  // +1 to previous robot count since new robot for that type
                    if(newrobotcount<10)
                    {
                        id_= string("UR0") + to_string(newrobotcount);
                    }
                    else
                    {
                        id_= string("UR") + to_string(newrobotcount);
                    }
                    out << currentrobot->id << " ==> " << id_ << endl;

                }
                currentrobot->id = id_;   // Update linked list robotID
                check = 0;
                battlefield.updateRobotPosition(id_, firePosX, firePosY, check); // Modify Battlefield state indirectly

                // Check if killed robot in enemy list, if yes remove from list so that when step will not consider this already-killed-robot
                for (auto enemy = enemylist.begin(); enemy != enemylist.end(); enemy++)
                {
                    if (enemy->first == firePosX && enemy->second == firePosY)
                    {
                        enemylist.erase(enemy);
                        return;
                    }
                }
            }
            else
            {
                out << "Miss! No robot at (" << firePosX << "," << firePosY << ")." << endl;
            }
        }
        out << endl;
    }

    void actionStep(Battlefield& battlefield,  robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) override
    {
        out << "TerminatorRoboCop actionStep" << endl;

        string targetRobotID;

        if (enemylist.empty())
        {
            if (possibleMoves.empty())
            {
                out << "No moves to make." << endl;
                return;
            }
            // Randomly choose a position to move from possible moves list if no enemy
            pair<int, int> chosenMove = possibleMoves[rand() % possibleMoves.size()];
            battlefield.setposition(robotPosX, robotPosY);
            updatePosition(robotActions, chosenMove.first, chosenMove.second);      // Update position value in linkedlist
            check=1;
            battlefield.updateRobotPosition(id_, robotPosX, robotPosY,check); // Modify Battlefield state indirectly
            out << "Stepped to (" << robotPosX << "," << robotPosY << "). No enemy killed." << endl;
            return;

        }
        else
        {
            // If theres enemy, randomly choose on enemy robot to step on from enemy list
            pair<int, int> chosenMove = enemylist[rand() % enemylist.size()];
            battlefield.setposition(robotPosX, robotPosY);

            auto killrobot = robotActions.getRobotByPosition(chosenMove.first , chosenMove.second);
            if (killrobot != nullptr)
            {
                targetRobotID = killrobot->id;
                out << "Stepped to (" << chosenMove.first << "," << chosenMove.second << "). Terminated robot "  << targetRobotID << endl;
            }
            else
            {
                out << "No robot found at position (" << chosenMove.first << "," << chosenMove.second << ")." << endl;
            }

            // Convert robotActionList node to DeadRobotQueue node
            DeadRobotQueue<string, int>::DeadRobotnode* newNode = new DeadRobotQueue<string, int>::DeadRobotnode();
            newNode->id = killrobot->id;
            newNode->lives = killrobot->lives;
            newNode->posX = killrobot->posX;
            newNode->posY = killrobot->posY;
            newNode->next = nullptr;

            updatePosition(robotActions, chosenMove.first, chosenMove.second);
            // enemy node live -1
            newNode->lives -=1;

            //check if live <=0, if yes then pass ;if no,enemy node past to queue list
            if(newNode->lives <= 0)
            {
                out << targetRobotID << " no more lives... End of robot " << targetRobotID << endl;
                endGameRobot.enqueue(newNode);
            }
            else
            {
                out <<  targetRobotID << " remains " << newNode->lives << " lives \n";
                out << targetRobotID << " enters the queue waiting to be revived ...\n";
                deadrobot.enqueue(newNode);
            }
            // delete the enemy node
            robotActions.deleteNode(targetRobotID);

            //Upgrade robot
            auto currentrobot = robotActions.getRobotByPosition(robotPosX, robotPosY);   // get current robot
            currentrobot->numofkills++;     // add kill count

           // Check if robot kill count >= 3 ?
            if(currentrobot->numofkills <3)
            {
                // If havent >= 3, output msg +1 kill count
                out << currentrobot->id << " kill count +1... Total kill count = " <<currentrobot->numofkills<< endl;
            }
            else
            {
                out << currentrobot->id  <<" upgraded! Upgrading to UltimateRobot...\n";
                newRobotType = "UR"; //get the old id to change to new id
                // count how many robots with same robot type in linkedlist and queues(maybe will have same type robot that is dead at the moment)
                listrobotcount = robotActions.countrobot(newRobotType);
                deadrobotcount = deadrobot.countrobot1(newRobotType);
                endrobotcount = endGameRobot.countrobot1(newRobotType);

                int newrobotcount = listrobotcount + deadrobotcount + endrobotcount+1;  // +1 to previous robot count since new robot for that type
                if(newrobotcount<10)
                {
                  id_= "UR0" + to_string(newrobotcount);
                }
                else
                {
                  id_= "UR" + to_string(newrobotcount);
                }
                out << currentrobot->id << " ==> " << id_ << endl;

            }

            currentrobot->id = id_;   // Update linked list robotID
            check=1;
            battlefield.updateRobotPosition(id_, robotPosX, robotPosY,check); // Modify Battlefield state indirectly
            return;
        }
        out << endl;
    }

    virtual void actions(Battlefield& battlefield, robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream &out) override
    {
        actionLook(battlefield, out);
        actionFire(battlefield, robotActions, deadrobot, endGameRobot,out);
        actionStep(battlefield, robotActions, deadrobot, endGameRobot,out);
    }

    ~TerminatorRoboCop(){};
protected:
};

// -----------------------------------------------------------------------------

class BlueThunder: public ShootingRobot
{
private:
    int firePosX, firePosY;
    int numOfKills = 0;
    int numOfLives = 0;
    vector<pair<int,int>> fireSequence;  // array that stores 8 neighbouring locations deviation value from robot location
    size_t fireSequenceIndex = 0;     // size_t to represent non-negative value (good for indexing and loop counting)
    int check=-1;
    int listrobotcount,deadrobotcount,endrobotcount;
    string changedId, newid, newRobotType;


public:

    BlueThunder(string id,int x, int y): Robot(id, x,y) {}

    void actionFire(Battlefield& battlefield, robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) override
    {
        out << "BlueThunder actionFire" << endl;
        fireSequence = { {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1} };
        firePosX = robotPosX + fireSequence[fireSequenceIndex].first;
        firePosY = robotPosY + fireSequence[fireSequenceIndex].second;

        // Check firing range in Battlefield range
        if (firePosX >= 0 && firePosX < battlefield.cols && firePosY >= 0 && firePosY < battlefield.rows)
        {
            //Check whether there's robot at target position
            if (battlefield.grid[firePosY][firePosX] != "NULL")
            {
                // If hit a robot, get the robotID
                string destroyedRobotID = battlefield.grid[firePosY][firePosX];

                // Display log stating robot killed the targeted robot
                out << "Hit! Robot " << destroyedRobotID << " at (" << firePosX << ", " << firePosY << ")." << endl;
                numOfKills++;   // Increase kill count

                string targetRobotID;
                battlefield.setposition(robotPosX, robotPosY);

                auto killrobot = robotActions.getRobotByPosition(firePosX, firePosY);
                if (killrobot != nullptr) {
                 targetRobotID = killrobot->id;
                }

                // Convert robotActionList node to DeadRobotQueue node
                DeadRobotQueue<string, int>::DeadRobotnode* newNode = new DeadRobotQueue<string, int>::DeadRobotnode();
                newNode->id = killrobot->id;
                newNode->lives = killrobot->lives;
                newNode->posX = killrobot->posX;
                newNode->posY = killrobot->posY;
                newNode->next = nullptr;

                // enemy node live -1
                newNode->lives -=1;

                //check if live <=0, if yes then pass ;if no,enemy node past to queue list
                if(newNode->lives <= 0){
                out << targetRobotID << " no more lives... End of robot " << targetRobotID << endl;
                endGameRobot.enqueue(newNode);
                }else{
                out <<  targetRobotID << " remains " << newNode->lives << " lives \n";
                out << targetRobotID << " enters the queue waiting to be revived ...\n";
                deadrobot.enqueue(newNode);
                }
                // delete the enemy node
                robotActions.deleteNode(targetRobotID);

               //Upgrade robot
                auto currentrobot = robotActions.getRobotByPosition(robotPosX, robotPosY);   // get current robot
                currentrobot->numofkills++;     // add kill count

               // Check if robot kill count >= 3 ?
                if(currentrobot->numofkills <3)
                {
                    // If havent >= 3, output msg +1 kill count
                    out << currentrobot->id << " kill count +1... Total kill count = " <<currentrobot->numofkills<< endl;
                }
                else
                {
                    out << currentrobot->id  <<" upgraded! Upgrading to MadBot...\n";
                    newRobotType = "MB"; //get the old id to change to new id
                    // count how many robots with same robot type in linkedlist and queues(maybe will have same type robot that is dead at the moment)
                    listrobotcount = robotActions.countrobot(newRobotType);
                    deadrobotcount = deadrobot.countrobot1(newRobotType);
                    endrobotcount = endGameRobot.countrobot1(newRobotType);

                    int newrobotcount = listrobotcount + deadrobotcount + endrobotcount+1;
                    if(newrobotcount<10)
                    {
                      id_= "MB0" + to_string(newrobotcount);     // +1 to previous robot count since new robot for that type
                    }
                    else
                    {
                      id_= "MB" + to_string(newrobotcount);
                    }
                    out << currentrobot->id << " ==> " << id_ << endl;

                }

                currentrobot->id = id_;   // Update linked list robotID
                check=0;
                battlefield.updateRobotPosition(id_, firePosX, firePosY,check); // Modify Battlefield state indirectly
            }
        }
        fireSequenceIndex = (fireSequenceIndex + 1) % fireSequence.size();
    }

     virtual void actions(Battlefield& battlefield, robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream &out) override
    {
         actionFire(battlefield, robotActions, deadrobot, endGameRobot, out);
    }


    ~BlueThunder(){};
protected:
};

// -----------------------------------------------------------------------------
class MadBot :  public ShootingRobot
{
private:
    int firePosX, firePosY;
    int numOfKills = 0;
    int check=-1;
    int listrobotcount,deadrobotcount,endrobotcount;
    string changedId, newid, newRobotType;


public:

    MadBot(string id,int x, int y): Robot(id, x,y) {}

    virtual void actionFire(Battlefield& battlefield, robotActionList<string, int> &robotActions, DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) override
    {
        out << "MadBot actionFire" << endl;

        // Get a random coordinate (x,y) from neighbouring 8 locations to fire at
        int firePosX = robotPosX + rand() % 3 - 1;  // Generate a random fire posX of deviation of -1 to 1 from current posX
        int firePosY = robotPosY + rand() % 3 - 1;  // Generate a random fire posY of deviation of -1 to 1 from current posY
        if (firePosX >= 0 && firePosX < battlefield.cols && firePosY >= 0 && firePosY < battlefield.rows  && (firePosX != robotPosX || firePosY != robotPosY))
        {
        //Check if there's a robot at the target position
        if (battlefield.grid[firePosY][firePosX] != "NULL")
            {
            // A robot is hit
            string destroyedRobotID = battlefield.grid[firePosY][firePosX];

            out << "Hit! Robot " << destroyedRobotID << " at (" << firePosX << ", " << firePosY << ")." << endl;
            numOfKills++;  // Increase the shot count

            string targetRobotID;
            battlefield.setposition(robotPosX, robotPosY);

            auto killrobot = robotActions.getRobotByPosition(firePosX, firePosY);
            if (killrobot != nullptr) {
             targetRobotID = killrobot->id;
            }

            // Convert robotActionList node to DeadRobotQueue node
            DeadRobotQueue<string, int>::DeadRobotnode* newNode = new DeadRobotQueue<string, int>::DeadRobotnode();
            newNode->id = killrobot->id;
            newNode->lives = killrobot->lives;
            newNode->posX = killrobot->posX;
            newNode->posY = killrobot->posY;
            newNode->next = nullptr;

            // enemy node live -1
            newNode->lives -=1;

                //check if live <=0, if yes then pass ;if no,enemy node past to queue list
                if(newNode->lives <= 0){
                out << targetRobotID << " no more lives... End of robot " << targetRobotID << endl;
                endGameRobot.enqueue(newNode);
                //endGameRobot.enqueue(newNode);
                }else{
                out <<  targetRobotID << " remains " << newNode->lives << " lives \n";
                out << targetRobotID << " enters the queue waiting to be revived ...\n";
                deadrobot.enqueue(newNode);
                }
            // delete the enemy node
            robotActions.deleteNode(targetRobotID);

           //Upgrade robot
            auto currentrobot = robotActions.getRobotByPosition(robotPosX, robotPosY);   // get current robot
            currentrobot->numofkills++;     // add kill count

           // Check if robot kill count >= 3 ?
            if(currentrobot->numofkills <3)
            {
                // If havent >= 3, output msg +1 kill count
                out << currentrobot->id << " kill count +1... Total kill count = " <<currentrobot->numofkills<< endl;
            }
            else
            {
                out << currentrobot->id  <<" upgraded! Upgrading to RoboTank...\n";
                newRobotType = "RT"; //get the old id to change to new id
                // count how many robots with same robot type in linkedlist and queues(maybe will have same type robot that is dead at the moment)
                listrobotcount = robotActions.countrobot(newRobotType);
                deadrobotcount = deadrobot.countrobot1(newRobotType);
                endrobotcount = endGameRobot.countrobot1(newRobotType);

                int newrobotcount = listrobotcount + deadrobotcount + endrobotcount+1;
                if(newrobotcount<10)
                {
                  id_= "RT0" + to_string(newrobotcount);     // +1 to previous robot count since new robot for that type
                }
                else
                {
                  id_= "RT" + to_string(newrobotcount);
                }
                out << currentrobot->id << " ==> " << id_ << endl;

            }

            currentrobot->id = id_;   // Update linked list robotID
            check=0;
            battlefield.updateRobotPosition(id_, firePosX, firePosY,check); // Modify Battlefield state indirectly
        }
      }
    }

     virtual void actions(Battlefield& battlefield, robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream &out) override
    {
         actionFire(battlefield, robotActions, deadrobot, endGameRobot, out);
    }

    ~MadBot(){};
protected:
};

// ------------------------- RoboTank -------------------------------------------
class RoboTank : public ShootingRobot
{
private:

    int numOfKills = 0;
    int check=-1;
    int listrobotcount,deadrobotcount,endrobotcount;
    string changedId, newid, newRobotType;

public:

    RoboTank(string id,int x, int y): Robot(id, x,y) {}

    virtual void actionFire(Battlefield& battlefield, robotActionList<string, int> &robotActions, DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) override
    {
        out << "RoboTank actionFire" << endl;

        // Get a random coordinate (x,y) inside the battlefield to fire at
        int firePosX = robotPosX + rand() % battlefield.cols;  // Generate a random fire posX in range of battlefield cols
        int firePosY = robotPosY + rand() % battlefield.rows;  // Generate a random fire posY in range of battlefield rows
        if (firePosX >= 0 && firePosX < battlefield.cols && firePosY >= 0 && firePosY < battlefield.rows  && (firePosX != robotPosX || firePosY != robotPosY))
        {
        //Check if there's a robot at the target position
            if (battlefield.grid[firePosY][firePosX] != "NULL")
            {
            // A robot is hit
                string destroyedRobotID = battlefield.grid[firePosY][firePosX];

                out << "Destroyed " << destroyedRobotID << " at (" << firePosX << ", " << firePosY << ")." << endl;
                numOfKills++;  // Increase the shot count

                string targetRobotID;
                battlefield.setposition(robotPosX, robotPosY);

                auto killrobot = robotActions.getRobotByPosition(firePosX, firePosY);
                if (killrobot != nullptr) {
                 targetRobotID = killrobot->id;
                }

                // Convert robotActionList node to DeadRobotQueue node
                DeadRobotQueue<string, int>::DeadRobotnode* newNode = new DeadRobotQueue<string, int>::DeadRobotnode();
                newNode->id = killrobot->id;
                newNode->lives = killrobot->lives;
                newNode->posX = killrobot->posX;
                newNode->posY = killrobot->posY;
                newNode->next = nullptr;

                // enemy node live -1
                newNode->lives -=1;

                //check if live <=0, if yes then pass ;if no,enemy node past to queue list
                if(newNode->lives <= 0){
                out << targetRobotID << " no more lives... End of robot " << targetRobotID << endl;
                endGameRobot.enqueue(newNode);
                }else{
                out <<  targetRobotID << " remains " << newNode->lives << " lives \n";
                out << targetRobotID << " enters the queue waiting to be revived ...\n";
                deadrobot.enqueue(newNode);
                }
                // delete the enemy node
                robotActions.deleteNode(targetRobotID);

                //Upgrade robot
                auto currentrobot = robotActions.getRobotByPosition(robotPosX, robotPosY);   // get current robot
                currentrobot->numofkills++;     // add kill count

               // Check if robot kill count >= 3 ?
                if(currentrobot->numofkills <3)
                {
                    // If havent >= 3, output msg +1 kill count
                    out << currentrobot->id << " kill count +1... Total kill count = " <<currentrobot->numofkills<< endl;
                }
                else
                {
                    out << currentrobot->id  <<" upgraded! Upgrading to UltimateRobot...\n";
                    newRobotType = "UR"; //get the old id to change to new id
                    // count how many robots with same robot type in linkedlist and queues(maybe will have same type robot that is dead at the moment)
                    listrobotcount = robotActions.countrobot(newRobotType);
                    deadrobotcount = deadrobot.countrobot1(newRobotType);
                    endrobotcount = endGameRobot.countrobot1(newRobotType);

                    int newrobotcount = listrobotcount + deadrobotcount + endrobotcount+1;
                    if(newrobotcount<10)
                    {
                      id_= "UR0" + to_string(newrobotcount);     // +1 to previous robot count since new robot for that type
                    }
                    else
                    {
                      id_= "UR" + to_string(newrobotcount);
                    }
                    out << currentrobot->id << " ==> " << id_ << endl;

                }

                currentrobot->id = id_;   // Update linked list robotID
                check=0;
                battlefield.updateRobotPosition(id_, firePosX, firePosY,check); // Modify Battlefield state indirectly


             }
        }
    }

     virtual void actions(Battlefield& battlefield, robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream &out) override
    {
         actionFire(battlefield, robotActions, deadrobot, endGameRobot, out);
    }

    ~RoboTank(){};
protected:
};

// ----------------------------------- Ultimate Robot ------------------------------------------

class UltimateRobot: public SeeingRobot, public MovingRobot, public ShootingRobot, public SteppingRobot
{
private:

    static int robotAutoIncrementInt_;
    int check=-1;

public:


    UltimateRobot(string id,int x, int y ) : Robot(id, x,y) {}     // Initialise robotID and position when creating an object with passed parameter value

    void actionLook(const Battlefield& battlefield, ostream& out) const override
    {
        out << "UltimateRobot actionLook" << endl;
        for (int i=-1; i<2; i++)
        {
            for (int j=-1; j<2; j++)
            {
                if(i==0  && j==0)
                {
                    continue;
                }
                else
                {
                    int lookPosX = robotPosX + j;
                    int lookPosY = robotPosY + i;

                    if (lookPosX >= 0 && lookPosX < battlefield.cols && lookPosY >= 0 && lookPosY < battlefield.rows)
                    {
                        if (battlefield.grid[lookPosY][lookPosX] != "NULL")
                        {
                            out << "Enemy spotted on (" << lookPosX << "," << lookPosY << ")." << endl;
                            enemylist.push_back({lookPosX, lookPosY});
                        }
                        else
                        {
                            possibleMoves.push_back({lookPosX, lookPosY});
                            continue;
                        }
                    }
                }
            }
        }
           out << endl;
    }

    void actionMove(Battlefield& battlefield, robotActionList<string, int> &robotActions,ostream& out)  override
    {
        out << "UltimateRobot actionMove" << endl;

        if (possibleMoves.empty()) {
            out << "No moves to make." << endl;
            return;
        }

        pair<int, int> chosenMove = possibleMoves[rand() % possibleMoves.size()];
        battlefield.setposition(robotPosX, robotPosY);
        updatePosition(robotActions, chosenMove.first, chosenMove.second);
        check=1;
        battlefield.updateRobotPosition(id_, chosenMove.first, chosenMove.second,check); // Modify Battlefield state indirectly
        out << "Moved to (" << robotPosX << "," << robotPosY << ")." << endl;

        out << endl;
    }

    virtual void actionFire(Battlefield& battlefield, robotActionList<string, int> &robotActions, DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) override
    {
         out << "UltimateRobot actionFire" << endl;

         for (int i = 0; i < 3; ++i)
         {
            int x, y;
            int firePosX, firePosY;
            do {
                // Generate x,y firing values in range of rows & cols (-cols/rows to +cols/rows)
                x = (rand() % (2 * battlefield.cols + 1)) - battlefield.cols;   // eg a x RN = 1 - 8(cols value) = -7 (meaning move left by 7 spaces)
                y = (rand() % (2 * battlefield.rows + 1)) - battlefield.rows;
                firePosX = robotPosX + x;                                       // eg robotPosX = 7, 7 +(-7) = 0 <-- firePosX will be (0,y)
                firePosY = robotPosY + y;
            } while (abs(x) + abs(y) < 1 || abs(x) + abs(y) > 10 ||
                    (firePosX == robotPosX && firePosY == robotPosY) ||
                    firePosX < 0 || firePosX >= battlefield.cols ||
                    firePosY < 0 || firePosY >= battlefield.rows);

            if (firePosX >= 0 && firePosX <= battlefield.cols && firePosY >= 0 && firePosY <= battlefield.rows) {
                out << "Firing at (" << firePosX << "," << firePosY << ")." << endl;
            } else {
                out << "Firing out of bounds at (" << firePosX << "," << firePosY << ")." << endl;
            }

            if (battlefield.grid[firePosY][firePosX] != "NULL") {
                out << "Hit! Robot at (" << firePosX << "," << firePosY << ")." << endl;

                string targetRobotID;
                battlefield.setposition(robotPosX, robotPosY);

                auto killrobot = robotActions.getRobotByPosition(firePosX, firePosY);
                if (killrobot != nullptr) {
                 targetRobotID = killrobot->id;
                }

                // Convert robotActionList node to DeadRobotQueue node
                DeadRobotQueue<string, int>::DeadRobotnode* newNode = new DeadRobotQueue<string, int>::DeadRobotnode();
                newNode->id = killrobot->id;
                newNode->lives = killrobot->lives;
                newNode->posX = killrobot->posX;
                newNode->posY = killrobot->posY;
                newNode->next = nullptr;

                // enemy node live -1
                newNode->lives -=1;

                //check if live <=0, if yes then pass ;if no,enemy node past to queue list
                if(newNode->lives <= 0){
                out << targetRobotID << " no more lives... End of robot " << targetRobotID << endl;
                endGameRobot.enqueue(newNode);
                }else{
                out <<  targetRobotID << " remains " << newNode->lives << " lives \n";
                out << targetRobotID << " enters the queue waiting to be revived ...\n";
                deadrobot.enqueue(newNode);
                }

                // delete the enemy node
                robotActions.deleteNode(targetRobotID);
                check=0;
                battlefield.updateRobotPosition(id_, firePosX, firePosY,check); // Modify Battlefield state indirectly

                // Check if killed robot in enemy list, if yes remove from list so that when step will not consider this already-killed-robot
                for (auto enemy = enemylist.begin(); enemy != enemylist.end(); enemy++)
                {
                    if (enemy->first == firePosX && enemy->second == firePosY)
                    {
                        enemylist.erase(enemy);
                        return;
                    }
                }
            } else {
                out << "Miss! No robot at (" << firePosX << "," << firePosY << ")." << endl;
            }
        }
        out << endl;
    }

    virtual void actionStep(Battlefield& battlefield,  robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream& out) override
    {
        out << "UltimateRobot actionStep" << endl;

        string targetRobotID;

        if (enemylist.empty()) {
            if (possibleMoves.empty()) {
                out << "No moves to make." << endl;
                return;
            }

            pair<int, int> chosenMove = possibleMoves[rand() % possibleMoves.size()];
            battlefield.setposition(robotPosX, robotPosY);
            updatePosition(robotActions, chosenMove.first, chosenMove.second);
            check=1;
            battlefield.updateRobotPosition(id_, robotPosX, robotPosY,check); // Modify Battlefield state indirectly
            out << "Stepped to (" << robotPosX << "," << robotPosY << "). No enemy killed." << endl;
            return;

        }
        else
        {
             pair<int, int> chosenMove = enemylist[rand() % enemylist.size()];
             battlefield.setposition(robotPosX, robotPosY);


             auto killrobot = robotActions.getRobotByPosition(chosenMove.first , chosenMove.second);
             if (killrobot != nullptr) {
                 targetRobotID = killrobot->id;
                 out << "Stepped to (" << chosenMove.first << "," << chosenMove.second << "). Terminated robot "  << targetRobotID << endl;
             } else {
                 out << "No robot found at position (" << chosenMove.first << "," << chosenMove.second << ")." << endl;
             }

              // Convert robotActionList node to DeadRobotQueue node
             DeadRobotQueue<string, int>::DeadRobotnode* newNode = new DeadRobotQueue<string, int>::DeadRobotnode();
             newNode->id = killrobot->id;
             newNode->lives = killrobot->lives;
             newNode->posX = killrobot->posX;
             newNode->posY = killrobot->posY;
             newNode->next = nullptr;

             updatePosition(robotActions, chosenMove.first, chosenMove.second);
            // enemy node live -1
             newNode->lives -=1;

                //check if live <=0, if yes then pass ;if no,enemy node past to queue list
                if(newNode->lives <= 0){
                out << targetRobotID << " no more lives... End of robot " << targetRobotID << endl;
                endGameRobot.enqueue(newNode);
                //endGameRobot.enqueue(newNode);
                }else{
                out <<  targetRobotID << " remains " << newNode->lives << " lives \n";
                out << targetRobotID << " enters the queue waiting to be revived ...\n";
                deadrobot.enqueue(newNode);
                }
             // delete the enemy node
             robotActions.deleteNode(targetRobotID);
             check=1;
             battlefield.updateRobotPosition(id_, robotPosX, robotPosY,check); // Modify Battlefield state indirectly
             return;

          out << endl;
        }

    }
    virtual void actions(Battlefield& battlefield, robotActionList<string, int> &robotActions,DeadRobotQueue<string, int> &deadrobot, DeadRobotQueue<string, int>& endGameRobot,ostream &out)
    {
        actionLook(battlefield, out);
        actionMove(battlefield, robotActions,out);
        actionFire(battlefield, robotActions, deadrobot, endGameRobot, out);
        actionStep(battlefield, robotActions,deadrobot, endGameRobot,out);
    }

    ~UltimateRobot(){};

};




#endif // ROBOT_H_INCLUDED
